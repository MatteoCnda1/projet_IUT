@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 serveur.py & goto :eof)
where python >nul 2>nul && (python serveur.py & goto :eof)
echo Python 3 est introuvable. Installez-le depuis https://www.python.org/downloads/ puis relancez ce fichier.
pause
