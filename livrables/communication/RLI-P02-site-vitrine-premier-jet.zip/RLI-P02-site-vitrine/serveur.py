"""Affiche le site RudyLink Infrastructure sur http://localhost:8080/ .

Lancement : double-clic sur ouvrir-le-site.bat (Windows), ou `python3 serveur.py`.
Arrêt : fermer la fenêtre, ou Ctrl+C. Le site n'est visible que sur cet ordinateur.
"""
import http.server
import os
import sys
import threading
import webbrowser

PORT = next((int(a) for a in sys.argv[1:] if a.isdigit()), 8080)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "site")


class Handler(http.server.SimpleHTTPRequestHandler):
    # Types explicites : sous Windows, le registre peut annoncer .js en text/plain, ce qui bloquerait la page.
    extensions_map = {
        ".html": "text/html; charset=utf-8",
        ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".json": "application/json",
        ".svg": "image/svg+xml",
        ".woff2": "font/woff2",
        ".jpg": "image/jpeg",
        ".png": "image/png",
        ".pdf": "application/pdf",
        ".txt": "text/plain; charset=utf-8",
        ".xml": "application/xml",
        "": "application/octet-stream",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, *args):
        pass


def main():
    server = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://localhost:{PORT}/"
    print(f"Site RudyLink Infrastructure : {url}")
    print("Fermez cette fenêtre (ou Ctrl+C) pour arrêter.")
    if "--sans-navigateur" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
