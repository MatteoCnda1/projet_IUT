#!/bin/sh
# Affiche le site sur http://localhost:8080/ (Ctrl+C pour arreter).
cd "$(dirname "$0")" && exec python3 serveur.py "$@"
